#!/usr/bin/env node
// 自定义签名脚本（Linux 无 wine）：直接跳过 Authenticode 签名。
// electron-builder 会传入待签名文件路径，我们不处理即视为跳过。
process.exit(0);
