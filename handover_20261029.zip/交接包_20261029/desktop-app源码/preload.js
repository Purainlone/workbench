const { ipcRenderer } = require('electron');
(function () {
  const api = {
    // 主窗口 -> 主进程
    openTag: () => ipcRenderer.send('dt-open'),
    closeTag: () => ipcRenderer.send('dt-close'),
    updateTag: (data) => ipcRenderer.send('dt-update', data),
    setShow: (k, v) => ipcRenderer.send('dt-set-show', k, v),
    refreshReq: () => ipcRenderer.send('dt-refresh'),
    // 主进程 -> 主窗口（小窗改了显示项 / 请求刷新 / 小窗被关）
    onTagSetShow: (cb) => ipcRenderer.on('dt-set-show', (_e, k, v) => cb(k, v)),
    onTagRefresh: (cb) => ipcRenderer.on('dt-refresh', () => cb()),
    onTagClosed: (cb) => ipcRenderer.on('dt-tag-closed', () => cb()),
    // 主进程 -> 桌面标签窗口（收到渲染数据）
    onTagRender: (cb) => ipcRenderer.on('dt-render', (_e, d) => cb(d)),
  };
  window.electronAPI = api;
})();
