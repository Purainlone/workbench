const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

let mainWin = null;
let tagWin = null;        // 桌面标签：由主进程独立托管，不依附主窗口渲染进程生命周期
let lastTagData = null;   // 最近一次推送给桌面标签的数据（开新窗时立即补一次）

function createWindow() {
  mainWin = new BrowserWindow({
    width: 1320,
    height: 880,
    minWidth: 980,
    minHeight: 640,
    icon: path.join(__dirname, 'assets/icon.png'),
    title: '李老师工作台',
    backgroundColor: '#f2f6f4',
    webPreferences: {
      contextIsolation: false,
      nodeIntegration: false,
      nativeWindowOpen: true,
      webSecurity: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });

  mainWin.loadFile(path.join(__dirname, 'app.html'));

  // 主窗口真正退出时，一并关掉桌面标签（应用退出了）
  mainWin.on('closed', () => { closeTag(); mainWin = null; });
}

/* ---------- 桌面标签：主进程独立托管的窗口 ---------- */
function openTag() {
  if (tagWin && !tagWin.isDestroyed()) { try { tagWin.focus(); } catch (e) {} return; }
  tagWin = new BrowserWindow({
    width: 340, height: 640, minWidth: 260, minHeight: 320,
    show: true, resizable: true, alwaysOnTop: true,   // 始终置顶，最小化主窗口也留在桌面
    title: '桌面标签', backgroundColor: '#f2f6f4',
    webPreferences: {
      contextIsolation: false,
      nodeIntegration: false,
      webSecurity: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });
  tagWin.loadFile(path.join(__dirname, 'desktag.html'));
  try { tagWin.setMenuBarVisibility(false); } catch (e) {}

  // 小窗被用户直接关掉（点了系统红叉）→ 通知主窗口同步状态
  tagWin.on('closed', () => {
    tagWin = null;
    if (mainWin && !mainWin.isDestroyed()) {
      try { mainWin.webContents.send('dt-tag-closed'); } catch (e) {}
    }
  });

  // 打开后立即推一次数据（延迟 300ms 等小窗脚本就绪）
  if (lastTagData) {
    setTimeout(() => {
      if (tagWin && !tagWin.isDestroyed()) {
        try { tagWin.webContents.send('dt-render', lastTagData); } catch (e) {}
      }
    }, 300);
  }
}

function closeTag() {
  if (tagWin && !tagWin.isDestroyed()) { try { tagWin.close(); } catch (e) {} }
  tagWin = null;
}

/* ---------- IPC：主窗口 / 桌面标签窗口 <-> 主进程 ---------- */
ipcMain.on('dt-open', () => { openTag(); });
ipcMain.on('dt-close', () => { closeTag(); });
ipcMain.on('dt-update', (e, data) => {
  lastTagData = data;
  if (tagWin && !tagWin.isDestroyed()) {
    try { tagWin.webContents.send('dt-render', data); } catch (e2) {}
  }
});
ipcMain.on('dt-set-show', (e, k, v) => {
  if (mainWin && !mainWin.isDestroyed()) {
    try { mainWin.webContents.send('dt-set-show', k, v); } catch (e2) {}
  }
});
ipcMain.on('dt-refresh', () => {
  if (mainWin && !mainWin.isDestroyed()) {
    try { mainWin.webContents.send('dt-refresh'); } catch (e2) {}
  }
});

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWin) {
      if (mainWin.isMinimized()) mainWin.restore();
      mainWin.focus();
    }
  });
  app.whenReady().then(createWindow);
  app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
}
