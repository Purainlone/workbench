import base64, json, urllib.request, sys

TOKEN = "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"
REPO = "Purainlone/workbench"
HDR = {"Authorization": f"token {TOKEN}", "Accept": "application/vnd.github+json", "User-Agent": "deploy"}

def api(path, data=None, method=None):
    req = urllib.request.Request(f"https://api.github.com{path}",
        data=json.dumps(data).encode() if data is not None else None,
        headers=HDR, method=method or ("POST" if data else "GET"))
    with urllib.request.urlopen(req) as r:
        return json.load(r)

# 1. 当前 main 指针与 tree
ref = api("/repos/Purainlone/workbench/git/ref/heads/main")
base_sha = ref["object"]["sha"]
print("base commit:", base_sha)
commit = api(f"/repos/Purainlone/workbench/git/commits/{base_sha}")
tree_sha = commit["tree"]["sha"]

# 2. 上传 blob：index.html = 小启动器；app.html = 完整应用
entries = []
for path_local, path_repo in [("/tmp/loader_index.html", "index.html"),
                              ("/workspace/李老师工作台_网页版_v127_2.6.61.html", "app.html")]:
    content = open(path_local, "rb").read()
    blob = api("/repos/Purainlone/workbench/git/blobs",
               {"content": base64.b64encode(content).decode(), "encoding": "base64"})
    print("blob", path_repo, blob["sha"][:8], "size:", len(content))
    entries.append({"path": path_repo, "mode": "100644", "type": "blob", "sha": blob["sha"]})

# 3. 新 tree + 提交推送
tree = api("/repos/Purainlone/workbench/git/trees", {"base_tree": tree_sha, "tree": entries})
print("new tree:", tree["sha"])
new_commit = api("/repos/Purainlone/workbench/git/commits", {
    "message": "v2.6.61 (v127): index.html 改为启动器——fetch app.html 校验完整后才渲染，防慢速链路截断（修复 missing / 半截应用问题）",
    "tree": tree["sha"], "parents": [base_sha]})
api("/repos/Purainlone/workbench/git/refs/heads/main",
    {"sha": new_commit["sha"], "force": False}, method="PATCH")
print("pushed commit:", new_commit["sha"])
